class InterestModel {
  final String name;
  final String iconPath;

  InterestModel({required this.name, required this.iconPath});
}
